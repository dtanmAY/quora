<?php
$con = mysqli_connect("localhost","root","","checker");
$query = mysqli_query($con, "SELECT * FROM checker");
$array = mysqli_fetch_array($query);
$msg = "";
if(isset($_POST['save'])){
  $text = $_POST['text'];
  $query = mysqli_query($con, "UPDATE checker SET check_text = '$text' WHERE id='23'");

  if($query){
    header("location: index.php");
  }else{
    $msg = "Someting Went Wrong";
  }
}

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Sample CKEditor page</title>
        <!-- src path should point to your copied ckeditor folder -->
        <script src="ckeditor/ckeditor.js"></script>
    </head>
    <body>
        <form method="post">
          <?php echo $msg; ?>
          <br>
	<!-- creating a text area for my editor in the form -->
        <textarea id="myeditor" name="text" placeholder="Enter Your Text Inside" rows="20"><?php echo $array['check_text']; ?></textarea>
      <button type="submit" name="save">SAVE</button>
            </form>

	<!-- creating a CKEditor instance called myeditor -->
	<script type="text/javascript">
		CKEDITOR.replace('myeditor');
	</script>
    </body>
</html>
